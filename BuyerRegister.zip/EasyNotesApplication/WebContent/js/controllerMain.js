//--user
//--login
$(document).on("click","#btnLogin",function()
{
	var result = isValidFormLogin();
	if(result=="true")
		{ $("#formLogin").submit(); }
	
	else
		{ $("#divStsMsgLogin").html(result); }
		
});

//--client model
//--user
function isValidFormLogin()
{
	if($.trim($("#txtUserName").val())=="")
		{ return "enter username"; }
	
	if($.trim($("#txtPassword").val())=="")
	{ return "enter Password"; }
	
	return "true";
}

function isValidFormItem()
{
	if($.trim($("#txtItemName").val())=="")
	{ return "enter item name"; }
	return "true/false";
}

//--items   save/update
$(document).on("click","#btnSave",function()
{
			var result = isValidFormUser();
			if(result=="true")
				{ $("#formUser").submit(); }
			
			else
				{ $("#divStsMsgUser").html(result); }
				
});

//--edit
$(document).on("click","#btnEdit",function()
{
	$("#hidMode").val(update);
	$("#hidID").val($(this).attr("param"));
	$("#txtItemName").val($(this).closest("tr").find('td:eq(1)').text());
	$("#txtItemDesc").val($(this).closest("tr").find('td:eq(2)').text());
	
});
//--Remove
$(document).on("click","#btnRemove", function()
{
	$("#hidMode").val("remove");
	$("#hidID").val($(this).attr("param"));
	var res = confirm("are you sure?");
		if(res == true){
			$("#formUpdate").submit();
		}


});

$(document).on("click", "#btnLogin", function() { 
	$("#divStsMsgLogin").html("");  var result = isValidFormLogin(); // use client-Model 

if (result == "true")  { 
	$.ajax(   {    type : "post",    url : "UserLogin",    data : $("#formLogin").serialize(),   
		complete : function(response, status)    { 
			onLogingComplete(response.responseText, status);   
			}   
	});  
	}  else  { 
		$("#divStsMsgLogin").html(result); 
		} 
}); 

function onLogingComplete(response, status) {  if (status == "success")  {   if (response == "SUCCESS")   {    document.location = "items.jsp";   }   else   {    $("#divStsMsgLogin").html(response);   }  }  else if (status == "error")  {   $("#divStsMsgLogin").html("Error while authenticating");  }  else  {   $("#divStsMsgLogin").html("Unknown error while authenticating");  } 
